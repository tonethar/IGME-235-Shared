import init from './main';
import utilities from './utilities';

const loadImages = utilities.loadImages; // alias
const imageSources = {
	explosions: "images/explosions.png"
};

// loadImages(imageSources,callback);
loadImages(imageSources,startGame);


function startGame(imageData){
	init(imageData);
}
