import Sprite from './Sprite';

export default class AnimatedSprite extends Sprite{
	constructor(x,y,fwd={x:0,y:1},speed=0){
		super(x,y,fwd,speed);
	}
	
	start(image,startY,width,height,frameWidth,frameHeight,frameDelay){
		this.image = image;
		this.startY = startY;
		this.width = width;
		this.height = height;
		this.frameWidth = frameWidth;
		this.frameHeight = frameHeight;
		this.frameDelay = frameDelay;
		
		this.active = true;
		this.totalFrames = Math.floor(this.image.width/this.frameWidth);
		this.frameIndex = 0;
		this.lastTime = 0;
	}
	
	draw(ctx){
		ctx.save();
		let halfW = this.width/2;
		let halfH = this.height/2;
		let frameNumber =  this.frameIndex % this.totalFrames;
		let imageX = frameNumber * this.frameWidth;
		let imageY = this.startY;
		ctx.drawImage( 
			this.image,        			// the image of the sprite sheet 
			imageX, imageY, this.frameWidth, this.frameHeight, // source
			this.x - halfW, this.y - halfH, this.width , this.height   // destination
		); 	
		ctx.restore();
	}
	
	move(dt=1/60){
		super.move(dt);
		this.lastTime += dt;
		if(this.lastTime >= this.frameDelay){
			this.lastTime = 0;
			this.frameIndex ++;
		}
		if(this.frameIndex >= this.totalFrames-1){
			//this.frameIndex = 0; // if we wanted to loop
			this.active = false;
		}
	}
	
}