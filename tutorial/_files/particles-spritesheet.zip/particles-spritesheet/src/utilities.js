let utilities = {
	getRandomUnitVector : getRandomUnitVector,
	getRandom : getRandom,
	getMouse : getMouse,
	loadImages : loadImages
}

export default utilities;

function getRandomUnitVector(){
	let x = getRandom(-1,1);
	let y = getRandom(-1,1);
	let length = Math.sqrt(x*x + y*y);
	if(length == 0){ // very unlikely
		x=1; // point right
		y=0;
		length = 1;
	} else{
		x /= length;
		y /= length;
	}

	return {x:x, y:y};
}

function getRandom(min, max) {
	return Math.random() * (max - min) + min;
}

// returns mouse position in local coordinate system of element
function getMouse(e){
	var mouse = {}; // make an object
	mouse.x = e.pageX - e.target.offsetLeft;
	mouse.y = e.pageY - e.target.offsetTop;
	return mouse;
}

function loadImages(imageSources,callback) {
	let numImages = Object.keys(imageSources).length
	let numLoadedImages = 0;
	
	// load images
	console.log("... start loading images ...");
	for(let imageName in imageSources) {
		console.log("... trying to load '" + imageName + "'");
		let img = new Image();
		img.src = imageSources[imageName];
		imageSources[imageName] = img;
		img.onload = function() {
			console.log(`SUCCESS: Image named "${imageName}" at ${this.src} loaded!`);
			if(++numLoadedImages >= numImages){
				console.log("... done loading images ...");
				callback(imageSources);
			}
		}
		img.onerror = function(){
			console.log(`ERROR: Image named "${imageName}" at ${this.src} loaded!`);
		}
	}
}