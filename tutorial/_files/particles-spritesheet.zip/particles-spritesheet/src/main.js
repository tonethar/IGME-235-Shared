import utilities from './utilities';
import EmitterSprite from './EmitterSprite';
import AnimatedSprite from './AnimatedSprite';
import RotatingEmitterSprite from './RotatingEmitterSprite';
export default init;

const getMouse = utilities.getMouse; // alias
const getRandomUnitVector = utilities.getRandomUnitVector; // alias

const canvas = document.querySelector("canvas");
const ctx = canvas.getContext("2d");
const screenWidth = 600;
const screenHeight = 400;

let sprites = [];
let imageData;
let explosionSound;

function init(argImageData){
	imageData = argImageData;
	
	// Load Sound
	explosionSound = new Howl({
		src: ['sounds/fireball.mp3'],
		volume: 0.2
	});
	
	let config1 = {
			red : 255,
			minXspeed : -0.25,
			minYspeed : -0.25,
			maxXspeed : 0.25,
			maxYspeed : 0.25,
			lifetime : 300,
			expansionRate : 0.05,
			numParticles : 100,
			xRange : 1,
			yRange : 1,
			useCircles : false,
			useSquares : true
	};
	let config2 = {
		red : 255,
		green : 150,
		lifetime: 50
	};
	let config3 = {
		red : 255,
		green : 255,
		blue: 255,
		minXspeed : 2.5,
		minYspeed : -0.05,
		maxXspeed : 5.0,
		maxYspeed : 0.05,
		lifetime : 200,
		expansionRate : 0.04,
		numParticles : 150,
		xRange : 1,
		yRange : 1,
		useCircles : false,
		useSquares : true
	};
	
	let emitter1 = createEmitter(100,100,config1);
	let emitter2 = createEmitter(500,100,config2);
	let emitter3 = createEmitter(20,350,config3);
	let emitter4 = createEmitter(100,100,config1);
	let emitter5 = createRotatingEmitter(300,200,config1);
	emitter4.speed=100;
	emitter4.fwd=getRandomUnitVector();
	emitter4.green=255;
	emitter5.rotationSpeed = -0.01;
	emitter5.useCircles = true;
	emitter5.blue=255;
	//emitter5.speed=100;
	//emitter5.fwd=getRandomUnitVector();
	
	sprites.push(emitter1);
	sprites.push(emitter2);
	sprites.push(emitter3);
	sprites.push(emitter4);
	sprites.push(emitter5);
	
	// hook up events
	canvas.onmousedown = doMousedown;
	
	// start animation
	loop();
}

function loop(timestamp){
	// schedule a call to loop() in 1/60th of a second
	requestAnimationFrame(loop);
	
	// draw background
	ctx.fillStyle="black";
	ctx.fillRect(0,0,screenWidth,screenHeight)

	for (let s of sprites){
		// move sprites
		s.move();
		
	// draw sprites
		s.draw(ctx);
		
		if (s.x <= 0 || s.x >= screenWidth){
			s.reflectX();
			s.move();
		}

		if (s.y <= 0 || s.y >= screenHeight){
			s.reflectY();
			s.move();
		}
	
	} // end for

	// if explosion is done, remove from array
	sprites = sprites.filter(s => s.active == false ? false : true);
} // end loop()
	
function doMousedown(e){
//	console.log(e);
	let mouse=getMouse(e);
//	console.log(`canvas coordinates: x=${mouse.x} y=${mouse.y}`);
	explosionSound.play();
	createExplosion(mouse.x,mouse.y);
}

function createEmitter(x,y,configObject){
		// EmitterSprite(x,y,fwd={x:0,y:1},speed=0)
		let emitter = new EmitterSprite(x,y);
		emitter.start(configObject);
		return emitter;
}

function createRotatingEmitter(x,y,configObject){
		// EmitterSprite(x,y,fwd={x:0,y:1},speed=0)
		let emitter = new RotatingEmitterSprite(x,y);
		emitter.start(configObject);
		return emitter;
}

function createExplosion(x,y){
	// AnimatedSprite(x,y,fwd={x:0,y:1},speed=0)
	let exp = new AnimatedSprite(x,y);
	exp.speed = 50; // it will "bounce"
	
	// 2nd row, 2 second duration
	// start(image,startY,width,height,frameWidth,frameHeight,frameDelay)
//	exp.start(imageData.explosions,65,128,128,64,64,1/8);
	
	// 4th row, 1 second duration
	exp.start(imageData.explosions,193,128,128,64,64,1/16);
	sprites.push(exp);
}

