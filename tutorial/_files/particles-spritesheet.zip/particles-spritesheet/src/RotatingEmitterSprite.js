import EmitterSprite from './EmitterSprite';

export default class RotatingEmitterSprite extends EmitterSprite{
	constructor(x,y,fwd={x:0,y:1},speed=0){
		super(x,y,fwd,speed);
		this.rotationSpeed = 0;
		this.rotation = 0;
	}
	
	draw(ctx){
			ctx.save();
			ctx.translate(this.x, this.y);
			ctx.rotate(this.rotation);
			for(var i=0;i<this._particles.length;i++){
				let p = this._particles[i];
							
				p.age += this.decayRate;
				p.r += this.expansionRate;
				p.x += p.xSpeed
				p.y += p.ySpeed
				let alpha = 1 - p.age/this.lifetime;
				ctx.fillStyle = `rgba(${this.red},${this.green},${this.blue},${alpha})`; 
				if(this.useSquares){
					ctx.fillRect(this.x - p.x, this.y - p.y, p.r, p.r);
				}
				
				if(this.useCircles){
					ctx.beginPath();
					ctx.arc(this.x - p.x, this.y - p.y, p.r, Math.PI * 2, false);
					ctx.closePath();
					ctx.fill();
				}
							
				// if the particle is too old, recycle it
				if(p.age >= this.lifetime){
					this._initParticle(p);
				}	
			} // end for loop of this._particles
			ctx.restore();

	} // end draw()
	
		move(dt=1/60){
			super.move(dt)
			this.rotation +=  this.rotationSpeed;
		}
}