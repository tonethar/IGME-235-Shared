import Sprite from './Sprite';
import utilities from './utilities';

const getRandom = utilities.getRandom; 

export default class EmitterSprite extends Sprite{
	constructor(x,y,fwd={x:0,y:1},speed=0){
		super(x,y,fwd,speed);
		// "private"
		this._particles = undefined;
		
		// public
		this.numParticles = 25;
		this.useCircles = true;
		this.useSquares = false;
		this.xRange = 4;
		this.yRange = 4;
		this.minXspeed = -1;
		this.maxXspeed = 1;
		this.minYspeed = 2;
		this.maxYspeed = 4;
		this.startRadius = 4;
		this.expansionRate = 0.3
		this.decayRate = 1.0;
		this.lifetime = 100;
		this.red = 0;
		this.green = 0;
		this.blue = 0;
	}

	start(configObject){
		Object.assign(this, configObject);
		// initialize particle array
		this._particles = [];
				
		// create exhaust particles
		for(let i=0; i< this.numParticles; i++){
			// create a particle object and add to array
			var p = {};
			this._particles.push(this._initParticle(p));
		}
	}
	
	draw(ctx){
			/* move and draw particles */
			// each frame, loop through _particles array
			// move each particle up or down the screen, and slightly left or right
			// increase its age
			// make it bigger, and fade it out based on its age
			// recycle it once it ages out
			ctx.save();
			
			for(var i=0;i<this._particles.length;i++){
				let p = this._particles[i];
							
				p.age += this.decayRate;
				p.r += this.expansionRate;
				p.x += p.xSpeed
				p.y += p.ySpeed
				let alpha = 1 - p.age/this.lifetime;
				ctx.fillStyle = `rgba(${this.red},${this.green},${this.blue},${alpha})`; 
				if(this.useSquares){
					// fill a rectangle	
					ctx.fillRect(p.x, p.y, p.r, p.r);
					// note: this code is easily modified to draw images! (which are more performant than vector graphics)
				}
				
				if(this.useCircles){
					ctx.beginPath();
					ctx.arc(p.x, p.y, p.r, Math.PI * 2, false);
					ctx.closePath();
					ctx.fill();
				}
							
				// if the particle is too old, recycle it
				if(p.age >= this.lifetime){
					this._initParticle(p);
				}	
			} // end for loop of this._particles
			
			ctx.restore();

	} // end draw()
			
	// "private" helper method
	_initParticle(p){
		// give it a random age when first created
		p.age = getRandom(0,this.lifetime);	
		p.x = this.x + getRandom(-this.xRange, this.xRange);
		p.y = this.y + getRandom(0, this.yRange);
		p.r = getRandom(this.startRadius/2, this.startRadius);
		p.xSpeed = getRandom(this.minXspeed, this.maxXspeed);
		p.ySpeed = getRandom(this.minYspeed, this.maxYspeed);
		return p;
	}
	
} // end class